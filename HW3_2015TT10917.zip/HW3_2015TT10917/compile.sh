#!/bin/bash

g++ main.cpp -std=c++11 -O3 -o main