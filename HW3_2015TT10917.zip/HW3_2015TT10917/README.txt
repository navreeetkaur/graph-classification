2015TT10917: Navreet Kaur
2015EE10434: Sanyam Gupta

Libraries:
(1) Numpy
(2) subprocess: To run bash commands from python script
(3) networkx: For checking subgraph isomorphism
(4) time: To check time of execution
(5) os: Generating paths to files
(6) collection: To use Ordered Dictionary
(7) gSpan binary executable: For mining frequent subgraph
(8) random: to shuffle dataset
(9) scikit-learn: To compute performance measures
(10) sys: To read arguments from command line


